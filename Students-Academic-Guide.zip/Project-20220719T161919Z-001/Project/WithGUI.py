from tkinter import *
import os

#Function to create password for new user
def setpassword(password,a):
    f = open(a + "\\Password.txt" ,'a')
    f.write(password)
    f.close()

#Function to create Folder of a subject in the User's Folder
def makechapter(a,subject,chapter):
    fpath = a + "\\" + subject
    os.mkdir(fpath + "\\" + chapter)

#Function to create All Chapters of Physics and Chemistry
def makechapters(a,subject):

    #Making chapters in Chemistry
    if subject == "Chemistry":
        makechapter(a,subject,"SBCOC")
        makechapter(a,subject,"Structure of atom")
        makechapter(a,subject,"Periodic Properties")
        makechapter(a,subject,"Chemical Bonding")
        makechapter(a,subject,"States of Matter")
        makechapter(a,subject,"Thermodynamics")
        makechapter(a,subject,"Equilibrium")
        makechapter(a,subject,"Redox Reactions")
        makechapter(a,subject,"Hydrogen")
        makechapter(a,subject,"S Block Elements")
        makechapter(a,subject,"P Block Elements")
        makechapter(a,subject,"GOC")
        makechapter(a,subject,"Hydrocarbons")
        makechapter(a,subject,"Environmental Chemistry")
    #Making chapters in Physics
    if subject == "Physics":
        makechapter(a,subject,"Units and Measurement")
        makechapter(a,subject,"Motion in Straight Line")
        makechapter(a,subject,"Motion in a Plane")
        makechapter(a,subject,"Laws of Motion")
        makechapter(a,subject,"WPE")
        makechapter(a,subject,"System of Particles")
        makechapter(a,subject,"Gravitation")
        makechapter(a,subject,"Solids")
        makechapter(a,subject,"Fluids")
        makechapter(a,subject,"Thermal Properties of Matter")
        makechapter(a,subject,"Thermodynamics")
        makechapter(a,subject,"Kinetic Theory")
        makechapter(a,subject,"Oscillations")
        makechapter(a,subject,"Waves")

#If the user has used application before(No is pressed)
def if_no():
    nowindow=Tk()
    nowindow.title("Entry:")
    username=StringVar()
    password=StringVar()
    nowindow.geometry('350x200')
    l2=Label(nowindow,text="Please enter your username")
    uentry=Entry(nowindow,textvariable=username)
    uentry.grid(row=0,column=1)
    l3=Label(nowindow,text="Please enter your password")
    pentry=Entry(nowindow,textvariable=password,show="*")
    pentry.grid(row=1,column=1)
    l2.grid(row=0,column=0)
    l3.grid(row=1,column=0)
    def norandom():
        password = pentry.get()
        stu=uentry.get()
        made = os.getcwd() + "\\our"
        directory = os.getcwd() + "\\" + stu
        files = os.listdir(os.getcwd())
        #Checking if folder exists
        if stu not in files:
            window2 = Tk()
            window2.geometry('250x50')
            window2.title("Folder not Found")
            l1= Label(window2, text="Folder doesn't exist.")
            l2 = Label(window2, text= "Please close this window and enter again.")
            l1.grid(row=0,column=0)
            l2.grid(row=1,column=0)
        else:
            #Checking password
            f2 = open(os.getcwd() + "\\" + stu + "\\Password.txt","r")
            pas = f2.read()
            if pas == password:
                porc = Tk()
                porc.title("Phy or Chem:")
                porc.geometry('400x100')
                label = Label(porc,text="Physics or Chemistry?")
                label.grid(row=0,column=0)
                #If user wants to study chemistry
                def Chemistry():
                    directory = os.getcwd() + "\\" + stu
                    chemistry = Tk()
                    chemistry.title("Chemistry")
                    def fun(a):
                        Sb=Tk()
                        Sb.title("Entry:")
                        directory = os.getcwd() + "\\" + uentry.get()
                        l1= Label(Sb, text="Theory")
                        l2= Label(Sb, text="Assignments")
                        l3= Label(Sb, text="Tests")
                        l4= Label(Sb, text="Notes")
                        l1.grid(column=0,row=0)
                        l2.grid(column=3,row=0)
                        l3.grid(column=6,row=0)
                        l4.grid(column=9,row=0)
                        #Theory PDFs
                        def run1():
                            path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Theory\\File.pdf"
                            os.startfile(path)
                        file1=Button(Sb,text="Theory1",command=run1)
                        #Assignment PDFs
                        def run2():
                            path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Assignments\\File.pdf"
                            os.startfile(path)
                        file2 = Button(Sb,text="Assignment1",command=run2)
                        #Test PDFs
                        def run3():
                            path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Tests\\File.pdf"
                            os.startfile(path)
                        file3 = Button(Sb,text="Test1",command=run3)
                        file1.grid(column=0,row=2)
                        file2.grid(column=3,row=2)
                        file3.grid(column=6,row=2)
                        #Wants to write his own notes
                        def notes():
                            name = "notes.txt"
                            path = uentry.get() + "\\Chemistry\\"+a+"\\"+name
                            f = open(path,'a')
                            f.close()
                            os.startfile(path)
                        file4=Button(Sb,text='notes',command=notes)
                        file4.grid(column=9,row=2)
                    #Different Chapters
                    b1 = Button(chemistry,text="SBCOC",width=20,command=lambda : fun("SBCOC"))
                    b1.grid(column=0, row=0)
                    b2=Button(chemistry,text="Structure of atom",width=20,command=lambda:fun("Structure of Atom"))
                    b2.grid(column=1, row=0)
                    b3=Button(chemistry,text="Periodic Properties",width=20,command=lambda:fun("Periodic Properties"))
                    b3.grid(column=2, row=0)
                    b4=Button(chemistry,text="Chemical Bonding",width=20,command=lambda:fun("Chemical Bonding"))
                    b4.grid(column=0, row=1)
                    b5=Button(chemistry,text="States of Matter",width=20,command=lambda:fun("States of Matter"))
                    b5.grid(column=1, row=1)
                    b6=Button(chemistry,text="Thermodynamics",width=20,command=lambda:fun("Thermodynamics"))
                    b6.grid(column=2, row=1)
                    b7=Button(chemistry,text="Equilibrium",width=20,command=lambda:fun("Equilibrium"))
                    b7.grid(column=0, row=2)
                    b8=Button(chemistry,text="Redox Reactions",width=20,command=lambda:fun("Redox Reactions"))
                    b8.grid(column=1, row=2)
                    b9=Button(chemistry,text="Hydrogen",width=20,command=lambda:fun("Hydrogen"))
                    b9.grid(column=2, row=2)
                    b10=Button(chemistry,text="S Block Elements",width=20,command=lambda : fun("S Block Elements"))
                    b10.grid(column=0, row=3)
                    b11=Button(chemistry,text="P Block Elements",width=20,command=lambda:fun("p block Elements"))
                    b11.grid(column=1, row=3)
                    b12=Button(chemistry,text="GOC",width=20,command=lambda:fun("GOC"))
                    b12.grid(column=2, row=3)
                    b13=Button(chemistry,text="Hydrocarbons",width=20,command=lambda:fun("Hydrocarbons"))
                    b13.grid(column=0, row=4)
                    b14=Button(chemistry,text="Environmental Chemistry",width=20,command=lambda:fun("Environmental Chemistry"))
                    b14.grid(column=1, row=4)
                #Physics has same code structure as Chemistry
                def Physics():
                    directory = os.getcwd() + "\\" + stu
                    physics = Tk()
                    physics.title("Physics")
                    def fun(a):
                        Sb=Tk()
                        Sb.title("Entry:")
                        directory = os.getcwd() + "\\" + uentry.get()
                        l1= Label(Sb, text="Theory")
                        l2= Label(Sb, text="Assignments")
                        l3= Label(Sb, text="Tests")
                        l4= Label(Sb, text="Notes")
                        l1.grid(column=0,row=0)
                        l2.grid(column=3,row=0)
                        l3.grid(column=6,row=0)
                        l4.grid(column=9,row=0)
                        def run1():
                            path = os.getcwd()+"\\our\\Physics\\"+a+"\\Theory\\File.pdf"
                            os.startfile(path)
                        file1=Button(Sb,text="Theory1",command=run1)
                        def run2():
                            path = os.getcwd()+"\\our\\Physics\\"+a+"\\Assignments\\File.pdf"
                            os.startfile(path)
                        file2 = Button(Sb,text="Assignment1",command=run2)
                        def run3():
                            path = os.getcwd()+"\\our\\Physics\\"+a+"\\Tests\\File.pdf"
                            os.startfile(path)
                        file3 = Button(Sb,text="Test1",command=run3)
                        file1.grid(column=0,row=2)
                        file2.grid(column=3,row=2)
                        file3.grid(column=6,row=2)
                        def notes():
                            name = "notes.txt"
                            path = uentry.get() + "\\Physics\\"+a+"\\"+name
                            f = open(path,'a')
                            f.close()
                            os.startfile(path)
                        file4=Button(Sb,text='notes',command=notes)
                        file4.grid(column=9,row=2)

                    b1=Button(physics,text="Units and Measurement",width=20,command=lambda:fun("Units and Measurement"))
                    b1.grid(column=0, row=0)
                    b2=Button(physics,text="Motion in Straight Line",width=20,command=lambda:fun("Motion in Straight Line"))
                    b2.grid(column=1, row=0)
                    b3=Button(physics,text="Motion in a Plane",width=20,command=lambda:fun("Motion in a Plane"))
                    b3.grid(column=2, row=0)
                    b4=Button(physics,text="Laws of Motion",width=20,command=lambda:fun("Laws of Motion"))
                    b4.grid(column=0, row=1)
                    b5=Button(physics,text="WPE",width=20,command=lambda:fun("WPE"))
                    b5.grid(column=1, row=1)
                    b6=Button(physics,text="System of Particles",width=20,command=lambda:fun("System of Particles"))
                    b6.grid(column=2, row=1)
                    b7=Button(physics,text="Gravitation",width=20,command=lambda:fun("Gravitation"))
                    b7.grid(column=0, row=2)
                    b8=Button(physics,text="Solids",width=20,command=lambda:fun("Solids"))
                    b8.grid(column=1, row=2)
                    b9=Button(physics,text="Fluids",width=20,command=lambda:fun("Fluids"))
                    b9.grid(column=2, row=2)
                    b10=Button(physics,text="Thermal Properties of Matter",width=20,command=lambda:fun("Thermal Properties of Matter"))
                    b10.grid(column=0, row=3)
                    b11=Button(physics,text="Thermodynamics",width=20,command=lambda:fun("Thermodynamics"))
                    b11.grid(column=1, row=3)
                    b12=Button(physics,text="Kinetic Theory",width=20,command=lambda:fun("Kinetic Theory"))
                    b12.grid(column=2, row=3)
                    b13=Button(physics,text="Oscillations",width=20,command=lambda:fun("Oscillations"))
                    b13.grid(column=0, row=4)
                    b14=Button(physics,text="Waves",width=20,command=lambda:fun("Waves"))
                    b14.grid(column=1, row=4)
                
                chem_btn = Button(porc,text="Chemistry",width=10,command=Chemistry)
                chem_btn.grid(row=1,column=0)
                phy_btn = Button(porc,text="Physics",width=10,command=Physics)
                phy_btn.grid(row=1,column=1)
                porc.mainloop()
                
            #Incorrect Password Entered    
            else:
                wpassword = Tk()
                wpassword.geometry('250x50')
                wpassword.title("Wrong Password")
                l1= Label(wpassword, text="Incorrect password entered.")
                l2 = Label(wpassword, text= "Please close this window and enter again.")
                l1.grid(row=0,column=0)
                l2.grid(row=1,column=0)
                
    submit=Button(nowindow,text="Submit",width=10, command = norandom)
    submit.grid(row=3,column=2)
    nowindow.mainloop()

            
#If the user is a new user(Yes is pressed)  

def if_yes():
    #Inputting username and password
    yeswindow=Tk()
    yeswindow.title("Entry:")
    username=StringVar()
    password=StringVar()
    yeswindow.geometry('350x200')
    l2=Label(yeswindow,text="Please enter your username")
    uentry=Entry(yeswindow,textvariable=username)
    uentry.grid(row=0,column=1)
    l3=Label(yeswindow,text="Please enter your password")
    pentry=Entry(yeswindow,textvariable=password,show="*")
    pentry.grid(row=1,column=1)
    l2.grid(row=0,column=0)
    l3.grid(row=1,column=0)
    def yesrandom():
        password = pentry.get()
        stu=uentry.get()
        
        mades = os.listdir(os.getcwd())
        #Checking if folder already exists
        if stu in mades:
            window2 = Tk()
            window2.geometry('250x50')
            window2.title("Folder Exists")
            l1= Label(window2, text="Folder already exists.")
            l2 = Label(window2, text= "Please close this window and enter again.")
            l1.grid(row=0,column=0)
            l2.grid(row=1,column=0)
        
        if stu not in mades:
            print("Done")
            path = os.getcwd() + "\\"+ stu
            print(path)
            os.mkdir(path)
            chemistry = os.getcwd()  + '\\'+ stu + '\\'+  'Chemistry'
            physics = os.getcwd()  + '\\' + stu + '\\'+  'Physics'
            os.mkdir(chemistry)
            os.mkdir(physics)
            makechapters(path,"Chemistry")
            makechapters(path,"Physics")
            setpassword(password,path)
            print("Folder made.")
            porc = Tk()
            porc.title("Phy or Chem:")
            porc.geometry('400x100')
            label = Label(porc,text="Physics or Chemistry?")
            label.grid(row=0,column=0)
            #Same code structure as before
            def Chemistry():
                chemistry = Tk()
                chemistry.title("Chemistry")
                def fun(a):
                    print(a)
                    Sb=Tk()
                    Sb.title("Entry:")
                    l1= Label(Sb, text="Theory")
                    l2= Label(Sb, text="Assignments")
                    l3= Label(Sb, text="Tests")
                    l4= Label(Sb, text="Notes")
                    l1.grid(column=0,row=0)
                    l2.grid(column=3,row=0)
                    l3.grid(column=6,row=0)
                    l4.grid(column=9,row=0)
                    def run1():
                        path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Theory\\File.pdf"
                        os.startfile(path)
                    file1=Button(Sb,text="Theory1",command=run1)
                    def run2():
                        path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Assignments\\File.pdf"
                        os.startfile(path)
                    file2 = Button(Sb,text="Assignment1",command=run2)
                    def run3():
                        path = os.getcwd()+"\\our\\Chemistry\\"+a+"\\Tests\\File.pdf"
                        os.startfile(path)
                    file3 = Button(Sb,text="Test1",command=run3)
                    file1.grid(column=0,row=2)
                    file2.grid(column=3,row=2)
                    file3.grid(column=6,row=2)
                    def notes():
                        name = "notes.txt"
                        path = uentry.get() + "\\Chemistry\\"+a+"\\"+name
                        f = open(path,'a')
                        f.close()
                        os.startfile(path)
                    file4=Button(Sb,text='notes',command=notes)
                    file4.grid(column=9,row=2)

                directory = os.getcwd() + "\\" + stu
                b1=Button(chemistry,text="SBCOC",width=20,command=lambda:fun("SBCOC"))
                b1.grid(column=0, row=0)
                b2=Button(chemistry,text="Structure of atom",width=20,command=lambda:fun("Structure of atom"))
                b2.grid(column=1, row=0)
                b3=Button(chemistry,text="Periodic Properties",width=20,command=lambda:fun("Periodic Properties"))
                b3.grid(column=2, row=0)
                b4=Button(chemistry,text="Chemical Bonding",width=20,command=lambda:fun("Chemical Bonding"))
                b4.grid(column=0, row=1)
                b5=Button(chemistry,text="States of Matter",width=20,command=lambda:fun("States of Matter"))
                b5.grid(column=1, row=1)
                b6=Button(chemistry,text="Thermodynamics",width=20,command=lambda : fun("Thermodynamics"))
                b6.grid(column=2, row=1)
                b7=Button(chemistry,text="Equilibrium",width=20,command=lambda:fun("Equilibrium"))
                b7.grid(column=0, row=2)
                b8=Button(chemistry,text="Redox Reactions",width=20,command=lambda:fun("Redox Reactions"))
                b8.grid(column=1, row=2)
                b9=Button(chemistry,text="Hydrogen",width=20,command=lambda:fun("Hydrogen"))
                b9.grid(column=2, row=2)
                b10=Button(chemistry,text="S Block Elements",width=20,command=lambda:fun("S Block Elements"))
                b10.grid(column=0, row=3)
                b11=Button(chemistry,text="P Block Elements",width=20,command=lambda:fun("p block Elements"))
                b11.grid(column=1, row=3)
                b12=Button(chemistry,text="GOC",width=20,command=lambda:fun("GOC"))
                b12.grid(column=2, row=3)
                b13=Button(chemistry,text="Hydrocarbons",width=20,command=lambda:fun("Hydrocarbons"))
                b13.grid(column=0, row=4)
                b14=Button(chemistry,text="Environmental Chemistry",width=20,command=lambda:fun("Environmental Chemistry"))
                b14.grid(column=1, row=4)
            def Physics():
                directory = os.getcwd() + "\\" + stu
                physics = Tk()
                physics.title("Physics")
                def fun(a):
                    Sb=Tk()
                    directory = os.getcwd() + "\\" + uentry.get()
                    l1= Label(Sb, text="Theory")
                    l2= Label(Sb, text="Assignments")
                    l3= Label(Sb, text="Tests")
                    l4= Label(Sb, text="Notes")
                    l1.grid(column=0,row=0)
                    l2.grid(column=3,row=0)
                    l3.grid(column=6,row=0)
                    l4.grid(column=9,row=0)
                    def run1():
                        path = os.getcwd()+"\\our\\Physics\\"+a+"\\Theory\\File.pdf"
                        os.startfile(path)
                    file1=Button(Sb,text="Theory1",command=run1)
                    def run2():
                        path = os.getcwd()+"\\our\\Physics\\"+a+"\\Assignments\\File.pdf"
                        os.startfile(path)
                    file2 = Button(Sb,text="Assignment1",command=run2)
                    def run3():
                        path = os.getcwd()+"\\our\\Physics\\"+a+"\\Tests\\File.pdf"
                        os.startfile(path)
                    file3 = Button(Sb,text="Test1",command=run3)
                    file1.grid(column=0,row=2)
                    file2.grid(column=3,row=2)
                    file3.grid(column=6,row=2)
                    def notes():
                        name = "notes.txt"
                        path = uentry.get() + "\\Physics\\"+a+"\\"+name
                        f = open(path,'a')
                        f.close()
                        os.startfile(path)
                    file4=Button(Sb,text='notes',command=notes)
                    file4.grid(column=9,row=2)
                b1=Button(physics,text="Units and Measurement",width=20,command=lambda:fun("Units and Measurement"))
                b1.grid(column=0, row=0)
                b2=Button(physics,text="Motion in Straight Line",width=20,command=lambda:fun("Motion in Straight Line"))
                b2.grid(column=1, row=0)
                b3=Button(physics,text="Motion in a Plane",width=20,command=lambda:fun("Motion in a Plane"))
                b3.grid(column=2, row=0)
                b4=Button(physics,text="Laws of Motion",width=20,command=lambda:fun("Laws of Motion"))
                b4.grid(column=0, row=1)
                b5=Button(physics,text="WPE",width=20,command=lambda:fun("WPE"))
                b5.grid(column=1, row=1)
                b6=Button(physics,text="System of Particles",width=20,command=lambda:fun("System of Particles"))
                b6.grid(column=2, row=1)
                b7=Button(physics,text="Gravitation",width=20,command=lambda:fun("Gravitation"))
                b7.grid(column=0, row=2)
                b8=Button(physics,text="Solids",width=20,command=lambda:fun("Solids"))
                b8.grid(column=1, row=2)
                b9=Button(physics,text="Fluids",width=20,command=lambda:fun("Fluids"))
                b9.grid(column=2, row=2)
                b10=Button(physics,text="Thermal Properties of Matter",width=20,command=lambda:fun("Thermal Properties of Matter"))
                b10.grid(column=0, row=3)
                b11=Button(physics,text="Thermodynamics",width=20,command=lambda:fun("Thermodynamics"))
                b11.grid(column=1, row=3)
                b12=Button(physics,text="Kinetic Theory",width=20,command=lambda:fun("Kinetic Theory"))
                b12.grid(column=2, row=3)
                b13=Button(physics,text="Oscillations",width=20,command=lambda:fun("Oscillations"))
                b13.grid(column=0, row=4)
                b14=Button(physics,text="Waves",width=20,command=lambda:fun("Waves"))
                b14.grid(column=1, row=4)
                
                
                
            chem_btn = Button(porc,text="Chemistry",width=10,command=Chemistry)
            chem_btn.grid(row=1,column=0)
            phy_btn = Button(porc,text="Physics",width=10,command=Physics)
            phy_btn.grid(row=1,column=1)
            porc.mainloop()
        

    submit=Button(yeswindow,text="Submit",width=10, command = yesrandom)
    submit.grid(row=3,column=2)
    yeswindow.mainloop()
    


#Opening window
window = Tk()
window.geometry('550x350')
window.title("Students' Academic Guide")
l1= Label(window, text="Are You a New Student?")
l1.pack()

#Checking for returning or new user
yes_btn = Button(window,text="Yes",width=10,command=if_yes)
yes_btn.pack()
no_btn = Button(window,text="No",width=10,command=if_no)
no_btn.pack()
x= PhotoImage(file='logo.png')
logo=Label(window,image=x)
logo.pack()
window.mainloop()
