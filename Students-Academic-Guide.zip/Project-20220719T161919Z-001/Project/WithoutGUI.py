import os
def makechapter(a,subject,chapter):
    fpath = a + "\\" + subject
    os.mkdir(fpath + "\\" + chapter)
def setpassword(password,a):
    f = open(a + "\\Password.txt" ,'a')
    f.write(password)
    f.close()
def checkpassword(a,enpass):
    f = open(a + "\\Password.txt" ,'r+')
    x = f.read()
    if x == enpass:
        return True
    else:
        return False

def makechapters(a,subject):
    '''Making chapters in
    Chemistry'''
    if subject == "Chemistry":
        makechapter(a,subject,"SBCOC")
        makechapter(a,subject,"Structure of atom")
        makechapter(a,subject,"Periodic Properties")
        makechapter(a,subject,"Chemical Bonding")
        makechapter(a,subject,"States of Matter")
        makechapter(a,subject,"Thermodynamics")
        makechapter(a,subject,"Equilibrium")
        makechapter(a,subject,"Redox Reactions")
        makechapter(a,subject,"Hydrogen")
        makechapter(a,subject,"S Block Elements")
        makechapter(a,subject,"P Block Elements")
        makechapter(a,subject,"GOC")
        makechapter(a,subject,"Hydrocarbons")
        makechapter(a,subject,"Environmental Chemistry")
    '''Making chapters in
    Physics'''
    if subject == "Physics":
        makechapter(a,subject,"Units and Measurement")
        makechapter(a,subject,"Motion in Straight Line")
        makechapter(a,subject,"Motion in a Plane")
        makechapter(a,subject,"Laws of Motion")
        makechapter(a,subject,"WPE")
        makechapter(a,subject,"System of Particles")
        makechapter(a,subject,"Gravitation")
        makechapter(a,subject,"Solids")
        makechapter(a,subject,"Fluids")
        makechapter(a,subject,"Thermal Properties of Matter")
        makechapter(a,subject,"Thermodynamics")
        makechapter(a,subject,"Kinetic Theory")
        makechapter(a,subject,"Oscillations")
        makechapter(a,subject,"Waves")
        
def theorypdfs(subject,chapter):
    path = os.getcwd() + "\\our" + "\\" + subject + "\\" + chapter + "\\Theory"
    files = os.listdir(path)
    print("Files that exist for that chapter:")
    for i in files:
        print(i)
    print("Please input the file to opened.")
    while(True):
        file = input()
        if file in files:
            path = path + "\\" + file
            os.startfile(path)
            break
        else:
            print("That file doesn't exist. Please enter again.")

def assignmentpdfs(subject,chapter):
    path = os.getcwd() + "\\our" + "\\" + subject + "\\" + chapter + "\\Assignments"
    files = os.listdir(path)
    print("Files that exist for that chapter:")
    for i in files:
        print(i)
    print("Please input the file to opened.")
    while(True):
        file = input()
        if file in files:
            path = path + "\\" + file
            os.startfile(path)
            break
        else:
            print("That file doesn't exist. Please enter again.")
            
def testpdfs(subject,chapter):
    path = os.getcwd()+"\\our" + "\\" + subject + "\\" + chapter + "\\Tests"
    files = os.listdir(path)
    print("Files that exist for that chapter:")
    for i in files:
        print(i)
    print("Please input the file to opened.")
    while(True):
        file = input()
        if file in files:
            path = path + "\\" + file
            os.startfile(path)
            break
        else:
            print("That file doesn't exist. Please enter again.")

def notemaking(a,subject,chapter):
    print("Please save work after finishing")
    '''print("When you're done, enter a single period on a line by itself.")
    buffer = []
    while True:
        print("> ", end="")
        line = input()
        if line == ".":
            break
        buffer.append(line)
    multiline_string = "\n".join(buffer)
    print("You entered...")
    print()
    print(multiline_string)
    '''
    name = chapter + "notes.txt"
    path = a + "\\" + subject+ "\\" + chapter + "\\" + name
    f = open(a + "\\" + subject+ "\\" + chapter + "\\" + name,'a')
    f.close()
    os.startfile(path)

print("Are you a new student?(Y/N)")
while True:
    ans = input()
    if ans == "Y" or ans == "N":
        break
    else:
        print("Please enter (Y/N)")
if ans == 'Y':
    path = os.getcwd()
    files = os.listdir(path)
    print("Folders that already exist:")
    print()
    if len(files) != 2: 
        for name in files:
            if name == 'Main.py' or name == 'our':
                continue
            else:
                print(name)
    else:
        print("No one has created a folder yet.")

    while(True):
        stu = input("Enter your name?")
        if stu not in files:   
            a = os.getcwd() + '//' + stu
            os.mkdir(a)
            chemistry = os.getcwd()  + '\\'+ stu + '\\'+  'Chemistry'
            physics = os.getcwd()  + '\\' + stu + '\\'+  'Physics'
            os.mkdir(chemistry)
            os.mkdir(physics)
            #Make all the chapters in the guys folder
            print("Folder created.")
            makechapters(a,"Chemistry")
            makechapters(a,"Physics")
            print("Please set a password for your folder:")
            password= input()
            setpassword(password,a)
            break
        else:
            print("Folder already exists.")
            
else:
    
    path = os.getcwd()
    files = os.listdir(path)
    
        
    print("Folders that already exist:")
    if len(files)!=2:
        for name in files:
            if name == 'Main.py' or name == 'our':
                continue
            else:
                print(name)
        print("Which folder do you wish to use?")
        while(True):
            stu = input("Enter your name?")
            if stu in files:   
                a = os.getcwd() + '//' + stu
                print("Please enter the password.")
                
                while(True):
                    password= input()
                    if checkpassword(a,password) == True:
                        print("File accessed.")
                        break
                    else:
                        print("Incorrect. Please enter again.")
                break
            else:
                print("Folder doesn't exist. Please enter again.")
    else:
        print("No one has used it yet. You are the first user.")
        stu = input("Enter your name?")
        a = os.getcwd() + '//' + stu
        os.mkdir(a)
        chemistry = os.getcwd()  + '\\'+ stu + '\\'+  'Chemistry'
        physics = os.getcwd()  + '\\' + stu + '\\'+  'Physics'
        os.mkdir(chemistry)
        os.mkdir(physics)
        #Make all the chapters in the guys folder
        print("Folder created.")
        makechapters(a,"Chemistry")
        makechapters(a,"Physics")
        
#path is a
print("")







while(True):
    subject = input("Do you want to do Physics or Chemistry?")
    while(True):
        if subject != "Physics" and subject!="Chemistry":
            subject = input("Please enter either Physics or Chemistry!!!!")
        else:
            break



    files = os.listdir(a + "\\" + subject)
    for name in files:
        print(name)



    chapter = input("Please enter the chapter:")
    while(True):
        if chapter not in files:
            chapter = input("Please enter a chapter that is listed.")
        else:
            break
    print("Chapter accessed")
    c=input("Choose Theory/Assignments/Tests/Notes:")
    while(True):
        if c!= "Theory" and c!="Assignments" and c!="Tests" and c !="Notes":
            c=input("Please enter Theory/Assignments/Tests/Videos/Notes:")
        else:
            break
    if c=="Theory":
        theorypdfs(subject,chapter)
    elif c == "Assignments":
        assignmentpdfs(subject,chapter)
    elif c == "Tests":
        testpdfs(subject,chapter)
    elif c== "Notes":
        
        notemaking(a,subject,chapter)



    print("Do you want to continue?")
    c=input()
    bol = False
    while(True):
        if c=="Yes":
            bol = False
            break
        elif c == "No":
            bol = True
            break
        else:
            c=input("Please enter 'Yes' or 'No'")
            continue
    if bol == True:
        break
    else:
        continue
